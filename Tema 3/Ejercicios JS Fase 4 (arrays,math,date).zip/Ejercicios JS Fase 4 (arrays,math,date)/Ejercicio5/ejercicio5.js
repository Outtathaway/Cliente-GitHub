function productoMatriz(){

    let matrizNum = [2,3,4];
    let resultado = 1;

    for (let i = 0; i < matrizNum.length; i++) {

        resultado = resultado * matrizNum[i]
        
    }

    alert(resultado);

    }